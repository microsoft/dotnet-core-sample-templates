﻿using Xunit;

[assembly: CollectionBehavior(CollectionBehavior.CollectionPerAssembly)]