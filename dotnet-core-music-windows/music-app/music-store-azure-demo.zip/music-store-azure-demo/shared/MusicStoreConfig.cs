namespace MusicStore
{
    public class StoreConfig
    {
        public const string ConnectionStringKey = "Data__DefaultConnection__ConnectionString";
    }
}